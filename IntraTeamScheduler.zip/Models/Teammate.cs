using System.ComponentModel.DataAnnotations;

namespace IntraTeamScheduler;

public class Teammate
{
    [Key]
    public Guid? ID { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }

    public string? Email { get; set; }
    //public int Position { get; set; } an int so i can make a schema of positions entity and have codes for each position.
}