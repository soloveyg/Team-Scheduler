using System.Runtime.InteropServices;

namespace IntraTeamScheduler;

public class NamePairs
{
    public Guid ID { get; set; }
    //public string Name1 { get; set; }
    public Teammate Name1 { get; set; }
    //public string Name2 { get; set; }
    public Teammate Name2 { get; set; }

} //front end recieves this object
