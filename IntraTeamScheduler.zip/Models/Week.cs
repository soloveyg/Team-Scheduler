namespace IntraTeamScheduler;

public class Week
{
    public Guid weekId { get; set; }
    public int weekNumber { get; set; }
    public List<NamePairs> Meetings { get; set; }
}