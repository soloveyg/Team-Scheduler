using IntraTeamScheduler.DataAccess;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace IntraTeamScheduler.Services;

public class CreateNamePairs
{

    public string DeleteTeammate(Guid id)
    {
        using (var db = new PairContext())
        {
            var existingTeammate = db.Teammates.Where(i => i.ID.ToString() == id.ToString().ToUpper()).ToList()
                .FirstOrDefault();

            if (db.BlackListedPairs.Any(x => x.Person1 == id || x.Person2 == id))
            {
                var teammateInBlacklistedPair = db.BlackListedPairs.Where(x => x.Person1 == id || x.Person2 == id)
                    .ToList();
                db.BlackListedPairs.RemoveRange(teammateInBlacklistedPair);
            }

            db.Teammates.Remove(existingTeammate);
            db.SaveChanges();
        }

        return "Teammate has been deleted";
    }

    public List<NamePairs> GetBlacklist()
    {
        using (var db = new BlacklistedPairContext())
        {
            List<NamePairs> blacklistedPairs = new List<NamePairs>();
            var blacklisters = db.BlackListedPairs.ToList();
            foreach (var pair in blacklisters)
            {
                NamePairs newPair = new NamePairs();
                newPair.ID = pair.ID.Value;
                newPair.Name1 = db.Teammates.First(x => x.ID == pair.Person1);
                newPair.Name2 = db.Teammates.First(x => x.ID == pair.Person2);
                blacklistedPairs.Add(newPair);
            }

            return blacklistedPairs;
        }
    }

    public string AddBlacklistPair(NamePairs pair)
    {
        using (var db = new BlacklistedPairContext())
        {
            BlackListedPair newPair = new BlackListedPair()
            {
                ID = Guid.NewGuid(),
                Person1 = pair.Name1.ID.Value,
                Person2 = pair.Name2.ID.Value
            };
            db.Add(newPair);
            db.SaveChanges();
        }
        return "Blacklisted pair has been saved.";
    }

    public string DeleteBlacklistPair(Guid id)
    {
        using (var db = new BlacklistedPairContext())
        {
            var pairToDelete = db.BlackListedPairs.FirstOrDefault(x => x.ID == id);
            db.Remove(pairToDelete);
            db.SaveChanges();
            return "pair has been deleted";
        }
    }
    
    public Teammate GetTeammate(Guid id)
    {
        try
        {
            using (var db = new TeammateContext())
            {
                var teammate = db.Teammates.FirstOrDefault(i => i.ID == id);
                return teammate;
            }
        }
        catch (Exception ex)
        {
            throw ex; 
        }
    }

    public List<Teammate> GetTeam()
    {
        try
        {
            using (var db = new TeammateContext())
            {
                var team = db.Teammates.ToList();
                return team;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public string EditTeammate([FromBody] Teammate teammate)
    {
        try
        {
            using (var db = new TeammateContext())
            {
                var existingTeammate = db.Teammates.FirstOrDefault(i => i.ID == teammate.ID);
                existingTeammate.FirstName = teammate.FirstName;
                existingTeammate.LastName = teammate.LastName;

                db.SaveChanges();
                return "Edits successfully changed.";
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public string CreateTeammate([FromBody] Teammate teammate)
    {
        try
        {
            //insert code for adding teammates to db
            using (var db = new TeammateContext())
            {
                var newTeammate = new Teammate()
                {
                    ID = Guid.NewGuid(),
                    FirstName = teammate.FirstName,
                    LastName = teammate.LastName,
                    Email = teammate.Email
                };
                db.Add(newTeammate);

                db.SaveChanges();
            }
        } catch (Exception ex)
        {
            throw ex;
        }

        return "Successfully added new teammate.";

    }

    public List<Pair> MakePairs()
    {
        using (var db = new PairContext())
        {
            var start = DateTime.Now;
            var allTeammates = new Queue<Teammate>(db.Teammates.ToList());
            Console.WriteLine($"get all teammates: {DateTime.Now - start}");

            if (allTeammates.Count == 0)
            {
                Exception ex = new Exception("How can I make a schedule if there's no members in the team? Do better and try again.");
                throw ex;
            }

            //this is every unique combo. in db form
            List<Pair> everyPair = new List<Pair>();
            start = DateTime.Now;
            var blacklisttable = db.BlackListedPairs.ToList();
            Console.WriteLine($"get all blacklist pairs duration: {DateTime.Now - start}");
            start = DateTime.Now;
            while (allTeammates.Count > 0)
            {
                var firstPerson = allTeammates.Dequeue();
                var listOfTeammates = allTeammates.ToList();
                for (int i = 0; i < listOfTeammates.Count; i++)
                {
                    Pair newPair = new Pair();
                    newPair.ID = Guid.NewGuid();
                    newPair.Person1 = firstPerson.ID.Value;
                    newPair.Person2 = listOfTeammates[i].ID.Value;
                    
                    var nonBlacklistCondition = blacklisttable.Any(x => 
                        (x.Person1 == newPair.Person1 || x.Person2 == newPair.Person1) && 
                        (x.Person1 == newPair.Person2 || x.Person2 == newPair.Person2));
                    if (!nonBlacklistCondition)
                    {
                        everyPair.Add(newPair);
                    }
                }
            }
            Console.WriteLine($"add pairs to list duration: {DateTime.Now - start}");
            db.AddRange(everyPair);
            return everyPair;
        }
    }

    public List<Week> SchedulePairs()
    {
        var pairs = MakePairs();
        Queue<Pair> pairList = new Queue<Pair>(pairs);

        var groupings = new List<List<Pair>>();
        var currentPair = pairList.Dequeue();
        var firstPair = new List<Pair>
        {
            currentPair
        };
        groupings.Add(firstPair);
        var currentPairIsUsed = false;
        var start = DateTime.Now;
        
        while (pairList.Any())
        {
            currentPair = pairList.Dequeue();
            
            for (int i = 0; i < groupings.Count; i++)
            {
                currentPairIsUsed = false;
                var currentList = groupings[i];
                var doesExist = currentList.Any(x => x.Person1 == currentPair.Person1) ||
                                currentList.Any(x => x.Person1 == currentPair.Person2) ||
                                currentList.Any(x => x.Person2 == currentPair.Person1) ||
                                currentList.Any(x => x.Person2 == currentPair.Person2);
                if (!doesExist)
                {
                    currentList.Add(currentPair);
                    currentPairIsUsed = true;
                    break;
                }
            }
            if (currentPairIsUsed == false)
            {
                var newList = new List<Pair>();
                newList.Add(currentPair);
                groupings.Add(newList);  
            }
        }
        Console.WriteLine($"create schedule pairs while duration: {DateTime.Now - start}");

        start = DateTime.Now;
        var scheduledPairs = new List<Week>();
        
        using (var db = new PairContext())
        {
            var teammatesListFromDb = db.Teammates.ToList();
            var weekCount = 1;
            foreach (var group in groupings)
            {
                var namePairList = new List<NamePairs>();
                for (int i = 0; i < group.Count; i++)
                {
                    var currentNamePair = group[i];
                    var newNamePair = new NamePairs
                    {
                        ID = currentNamePair.ID.Value,
                        Name1 = teammatesListFromDb.First(x => x.ID == currentNamePair.Person1),
                        Name2 = teammatesListFromDb.First(x => x.ID == currentNamePair.Person2)
                    };
                    namePairList.Add(newNamePair);
                }

                var newWeek = new Week 
                {
                    weekId = Guid.NewGuid(),
                    weekNumber = weekCount,
                    Meetings = namePairList 
                };
                
                weekCount++;
                scheduledPairs.Add(newWeek);
                
            }
        }
        Console.WriteLine($"create response object duration: {DateTime.Now - start}");
        return scheduledPairs;
    }
}