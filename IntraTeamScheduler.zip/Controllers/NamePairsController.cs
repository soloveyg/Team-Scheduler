﻿using Microsoft.AspNetCore.Mvc;
using IntraTeamScheduler.Services;

namespace IntraTeamScheduler.Controllers;

[ApiController]
[Route("[controller]")]
public class NamePairsController : ControllerBase
{

    private readonly ILogger<NamePairsController> _logger;

    public NamePairsController(ILogger<NamePairsController> logger)
    {
        _logger = logger;
    }

    [HttpGet, Route("SchedulePairs")]
    public IActionResult SchedulePairs()
    {
        var createPairs = new CreateNamePairs();
        Console.WriteLine($"start: {DateTime.Now}");
        var result = createPairs.SchedulePairs();
        return Ok(result);
    }

    [HttpGet, Route("getTeam")]
    public async Task<IActionResult> getTeam()
    {
        var teammates = new CreateNamePairs();
        var result = teammates.GetTeam(); 

        return Ok(result);
    }

    [HttpPost, Route("AddTeammate")] // the endpoint for entering individuals into the db 
    //when sending a single user to this endpoint, only send in first name and last name. delete the id from body on swagger
    public IActionResult addTeammate([FromBody] Teammate teammate)
    {
        var createTeam = new CreateNamePairs();

        var result = createTeam.CreateTeammate(teammate);
        
        return Ok(result);
    }

    [HttpPut, Route("EditTeammate")]
    //works by sending the correct id,
    public IActionResult editTeammate([FromBody] Teammate teammate)
    {
        var editTeammate = new CreateNamePairs();
        var result = editTeammate.EditTeammate(teammate);
        return Ok(result);
    }
    
    [HttpPost, Route("AddBlacklistPair")]
    public IActionResult addBlacklistPair([FromBody] NamePairs blacklisters)
    {
        var blacklistPair = new CreateNamePairs();
        var result = blacklistPair.AddBlacklistPair(blacklisters);
        return Ok(result);
    }

    [HttpDelete, Route("DeleteBlacklistPair")]
    public IActionResult deleteBlacklistPair([FromBody] Guid blacklistPairID)
    {
        var deletePair = new CreateNamePairs();
        var result = deletePair.DeleteBlacklistPair(blacklistPairID);
        return Ok(result);
    }

    [HttpGet, Route("GetTeammate")]
    public IActionResult getTeammate([FromQuery] Teammate person)
    {
        var findEmployee = new CreateNamePairs();
        var employee = findEmployee.GetTeammate(person.ID.Value);
        return Ok(employee);
    }

    [HttpGet, Route("GetBlacklistPairs")]
    public IActionResult GetBlacklistPair()
    {
        var getBlacklistedPairs = new CreateNamePairs();
        var result = getBlacklistedPairs.GetBlacklist();
        return Ok(result);
    }

    [HttpDelete, Route("DeleteTeammate")]
    public IActionResult DeleteTeammate([FromBody] Teammate teammate)
    {
        var deleteTeammate = new CreateNamePairs();
        var result = deleteTeammate.DeleteTeammate(teammate.ID.Value);
        return Ok(result);
    }
}
