using Microsoft.EntityFrameworkCore;

namespace IntraTeamScheduler.DataAccess;

public class PairContext : DbContext
{
    public DbSet<Pair> Pairs { get; set; }
    public DbSet<Teammate> Teammates { get; set; }
    public DbSet<Week> Weeks { get; set; }
    public DbSet<BlackListedPair> BlackListedPairs { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer(
            "Server=tcp:ciaddiedb.database.windows.net,1433;Initial Catalog=intrateam-creator;Persist Security Info=False;User ID=crutelio;Password=Pothosplant6969@;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"
        );
    }
}



public class Pair
{
    public Guid? ID { get; set; }
    public Guid Person1 { get; set; }
    public Guid Person2 { get; set; }

    //public int WeekNumber { get; set; }
}