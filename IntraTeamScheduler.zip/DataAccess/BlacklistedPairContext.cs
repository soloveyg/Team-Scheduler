using Microsoft.EntityFrameworkCore;

namespace IntraTeamScheduler.DataAccess;

public class BlacklistedPairContext : DbContext
{
    public DbSet<BlackListedPair> BlackListedPairs { get; set; }
    public DbSet<Teammate> Teammates { get; set; }
    
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer(
            "Server=tcp:ciaddiedb.database.windows.net,1433;Initial Catalog=intrateam-creator;Persist Security Info=False;User ID=crutelio;Password=Pothosplant6969@;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"
        );
    }
}

public class BlackListedPair
{
    public Guid? ID { get; set; } 
    public Guid Person1 { get; set; } 
    public Guid Person2 { get; set; }
}