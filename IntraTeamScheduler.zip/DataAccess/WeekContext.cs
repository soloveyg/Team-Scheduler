using Microsoft.EntityFrameworkCore;

namespace IntraTeamScheduler.DataAccess;

public class WeekContext : DbContext
{
    public DbSet<WeekContext> Weeks { get; set; }
}

public class Week
{
    public Guid ID { get; set; }
    public int WeekNumber { get; set; }
}
