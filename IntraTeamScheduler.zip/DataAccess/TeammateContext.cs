

using System.Runtime.Serialization;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace IntraTeamScheduler.DataAccess;
using Microsoft.EntityFrameworkCore;
using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

public class TeammateContext : DbContext
{
    public DbSet<Teammate> Teammates { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer(
            "Server=tcp:ciaddiedb.database.windows.net,1433;Initial Catalog=intrateam-creator;Persist Security Info=False;User ID=crutelio;Password=Pothosplant6969@;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"
        );
    }
    
    /*
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Teammate>()
            .Property(e => e.ID)
            .HasConversion(i => new GuidToStringConverter())
    }
    */
    
}
