export class Employee {
    constructor(firstName, lastName, email, id = null) {
        
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.id = id;
    }
    getName() {
        return this.firstName + ' ' + this.lastName;
    }

}