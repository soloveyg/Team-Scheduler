[
    {
        "weekId": "e38138b6-cc71-44d4-9255-95fb5402a85d",
        "weekNumber": 1,
        "meetings": [
            {
                "id": "6c63a5d5-5196-4d3d-a31c-ffc1e2f2e172",
                "name1": {
                    "id": "88d0dc37-6b00-49d2-9049-47ce0a46f2a9",
                    "firstName": "Jose",
                    "lastName": "R"
                },
                "name2": {
                    "id": "560ec5fd-6302-4ce6-883e-05665e54320b",
                    "firstName": "Gloria",
                    "lastName": "S"
                }
            },
            {
                "id": "f82c28bc-da4c-4620-be27-8ec17a3a176c",
                "name1": {
                    "id": "0e7f2a63-cd84-4ed7-92c8-a93de7122d5e",
                    "firstName": "Gloria",
                    "lastName": "S"
                },
                "name2": {
                    "id": "5089c5ee-4529-4906-bfce-439cd1d38d7e",
                    "firstName": "Ciaddie",
                    "lastName": "R"
                }
            },
            {
                "id": "b8942eae-c7af-4c6f-943c-3b7850f1ddff",
                "name1": {
                    "id": "993ccf0e-360f-4baa-b546-6e78d4952ea8",
                    "firstName": "Ciaddie",
                    "lastName": "R"
                },
                "name2": {
                    "id": "ff680c49-e8fd-484d-81e3-01cac9017253",
                    "firstName": "Jacob",
                    "lastName": "D"
                }
            },
            {
                "id": "6f6f8d5d-7084-48ac-b945-ee97b178c4c1",
                "name1": {
                    "id": "7c9eb64b-41b7-4451-a02e-54e280b5fc8d",
                    "firstName": "Jacob",
                    "lastName": "D"
                },
                "name2": {
                    "id": "1385e200-571d-4582-bbe8-1a534db43c11",
                    "firstName": "Stacy",
                    "lastName": "D"
                }
            },
            {
                "id": "6cc7d688-2c62-46d3-884c-f42bd56e5d7d",
                "name1": {
                    "id": "efcd5b0c-886c-410e-8a61-c8df1d3c8930",
                    "firstName": "Stacy",
                    "lastName": "D"
                },
                "name2": {
                    "id": "3ad25f92-76ab-452a-a3a6-78fcf8c2c49b",
                    "firstName": "Sam",
                    "lastName": "C"
                }
            }
        ]
    },
    {
        "weekId": "d113ffad-c0d3-435c-ad87-0d11da2174d5",
        "weekNumber": 2,
        "meetings": [
            {
                "id": "6c63a5d5-5196-4d3d-a31c-ffc1e2f2e172",
                "name1": {
                    "id": "88d0dc37-6b00-49d2-9049-47ce0a46f2a9",
                    "firstName": "Jose",
                    "lastName": "R"
                },
                "name2": {
                    "id": "560ec5fd-6302-4ce6-883e-05665e54320b",
                    "firstName": "Gloria",
                    "lastName": "S"
                }
            },
            {
                "id": "f82c28bc-da4c-4620-be27-8ec17a3a176c",
                "name1": {
                    "id": "0e7f2a63-cd84-4ed7-92c8-a93de7122d5e",
                    "firstName": "Gloria",
                    "lastName": "S"
                },
                "name2": {
                    "id": "5089c5ee-4529-4906-bfce-439cd1d38d7e",
                    "firstName": "Ciaddie",
                    "lastName": "R"
                }
            },
            {
                "id": "b8942eae-c7af-4c6f-943c-3b7850f1ddff",
                "name1": {
                    "id": "993ccf0e-360f-4baa-b546-6e78d4952ea8",
                    "firstName": "Ciaddie",
                    "lastName": "R"
                },
                "name2": {
                    "id": "ff680c49-e8fd-484d-81e3-01cac9017253",
                    "firstName": "Jacob",
                    "lastName": "D"
                }
            },
            {
                "id": "6f6f8d5d-7084-48ac-b945-ee97b178c4c1",
                "name1": {
                    "id": "7c9eb64b-41b7-4451-a02e-54e280b5fc8d",
                    "firstName": "Jacob",
                    "lastName": "D"
                },
                "name2": {
                    "id": "1385e200-571d-4582-bbe8-1a534db43c11",
                    "firstName": "Stacy",
                    "lastName": "D"
                }
            },
            {
                "id": "6cc7d688-2c62-46d3-884c-f42bd56e5d7d",
                "name1": {
                    "id": "efcd5b0c-886c-410e-8a61-c8df1d3c8930",
                    "firstName": "Stacy",
                    "lastName": "D"
                },
                "name2": {
                    "id": "3ad25f92-76ab-452a-a3a6-78fcf8c2c49b",
                    "firstName": "Sam",
                    "lastName": "C"
                }
            }
        ]
    },
    {
        "weekId": "68e2d711-ca70-49e3-86cb-19d2703b8c3f",
        "weekNumber": 3,
        "meetings": [
            {
                "id": "6c63a5d5-5196-4d3d-a31c-ffc1e2f2e172",
                "name1": {
                    "id": "88d0dc37-6b00-49d2-9049-47ce0a46f2a9",
                    "firstName": "Jose",
                    "lastName": "R"
                },
                "name2": {
                    "id": "560ec5fd-6302-4ce6-883e-05665e54320b",
                    "firstName": "Gloria",
                    "lastName": "S"
                }
            },
            {
                "id": "f82c28bc-da4c-4620-be27-8ec17a3a176c",
                "name1": {
                    "id": "0e7f2a63-cd84-4ed7-92c8-a93de7122d5e",
                    "firstName": "Gloria",
                    "lastName": "S"
                },
                "name2": {
                    "id": "5089c5ee-4529-4906-bfce-439cd1d38d7e",
                    "firstName": "Ciaddie",
                    "lastName": "R"
                }
            },
            {
                "id": "b8942eae-c7af-4c6f-943c-3b7850f1ddff",
                "name1": {
                    "id": "993ccf0e-360f-4baa-b546-6e78d4952ea8",
                    "firstName": "Ciaddie",
                    "lastName": "R"
                },
                "name2": {
                    "id": "ff680c49-e8fd-484d-81e3-01cac9017253",
                    "firstName": "Jacob",
                    "lastName": "D"
                }
            },
            {
                "id": "6f6f8d5d-7084-48ac-b945-ee97b178c4c1",
                "name1": {
                    "id": "7c9eb64b-41b7-4451-a02e-54e280b5fc8d",
                    "firstName": "Jacob",
                    "lastName": "D"
                },
                "name2": {
                    "id": "1385e200-571d-4582-bbe8-1a534db43c11",
                    "firstName": "Stacy",
                    "lastName": "D"
                }
            },
            {
                "id": "6cc7d688-2c62-46d3-884c-f42bd56e5d7d",
                "name1": {
                    "id": "efcd5b0c-886c-410e-8a61-c8df1d3c8930",
                    "firstName": "Stacy",
                    "lastName": "D"
                },
                "name2": {
                    "id": "3ad25f92-76ab-452a-a3a6-78fcf8c2c49b",
                    "firstName": "Sam",
                    "lastName": "C"
                }
            }
        ]
    },
    {
        "weekId": "351ea248-c190-4b74-8bdf-12b3b3afa388",
        "weekNumber": 4,
        "meetings": [
            {
                "id": "6c63a5d5-5196-4d3d-a31c-ffc1e2f2e172",
                "name1": {
                    "id": "88d0dc37-6b00-49d2-9049-47ce0a46f2a9",
                    "firstName": "Jose",
                    "lastName": "R"
                },
                "name2": {
                    "id": "560ec5fd-6302-4ce6-883e-05665e54320b",
                    "firstName": "Gloria",
                    "lastName": "S"
                }
            },
            {
                "id": "f82c28bc-da4c-4620-be27-8ec17a3a176c",
                "name1": {
                    "id": "0e7f2a63-cd84-4ed7-92c8-a93de7122d5e",
                    "firstName": "Gloria",
                    "lastName": "S"
                },
                "name2": {
                    "id": "5089c5ee-4529-4906-bfce-439cd1d38d7e",
                    "firstName": "Ciaddie",
                    "lastName": "R"
                }
            },
            {
                "id": "b8942eae-c7af-4c6f-943c-3b7850f1ddff",
                "name1": {
                    "id": "993ccf0e-360f-4baa-b546-6e78d4952ea8",
                    "firstName": "Ciaddie",
                    "lastName": "R"
                },
                "name2": {
                    "id": "ff680c49-e8fd-484d-81e3-01cac9017253",
                    "firstName": "Jacob",
                    "lastName": "D"
                }
            },
            {
                "id": "6f6f8d5d-7084-48ac-b945-ee97b178c4c1",
                "name1": {
                    "id": "7c9eb64b-41b7-4451-a02e-54e280b5fc8d",
                    "firstName": "Jacob",
                    "lastName": "D"
                },
                "name2": {
                    "id": "1385e200-571d-4582-bbe8-1a534db43c11",
                    "firstName": "Stacy",
                    "lastName": "D"
                }
            },
            {
                "id": "6cc7d688-2c62-46d3-884c-f42bd56e5d7d",
                "name1": {
                    "id": "efcd5b0c-886c-410e-8a61-c8df1d3c8930",
                    "firstName": "Stacy",
                    "lastName": "D"
                },
                "name2": {
                    "id": "3ad25f92-76ab-452a-a3a6-78fcf8c2c49b",
                    "firstName": "Sam",
                    "lastName": "C"
                }
            }
        ]
    },
    {
        "weekId": "c45eb7bb-f48f-4715-abe2-b30ff552e9f2",
        "weekNumber": 5,
        "meetings": [
            {
                "id": "6c63a5d5-5196-4d3d-a31c-ffc1e2f2e172",
                "name1": {
                    "id": "88d0dc37-6b00-49d2-9049-47ce0a46f2a9",
                    "firstName": "Jose",
                    "lastName": "R"
                },
                "name2": {
                    "id": "560ec5fd-6302-4ce6-883e-05665e54320b",
                    "firstName": "Gloria",
                    "lastName": "S"
                }
            },
            {
                "id": "f82c28bc-da4c-4620-be27-8ec17a3a176c",
                "name1": {
                    "id": "0e7f2a63-cd84-4ed7-92c8-a93de7122d5e",
                    "firstName": "Gloria",
                    "lastName": "S"
                },
                "name2": {
                    "id": "5089c5ee-4529-4906-bfce-439cd1d38d7e",
                    "firstName": "Ciaddie",
                    "lastName": "R"
                }
            },
            {
                "id": "b8942eae-c7af-4c6f-943c-3b7850f1ddff",
                "name1": {
                    "id": "993ccf0e-360f-4baa-b546-6e78d4952ea8",
                    "firstName": "Ciaddie",
                    "lastName": "R"
                },
                "name2": {
                    "id": "ff680c49-e8fd-484d-81e3-01cac9017253",
                    "firstName": "Jacob",
                    "lastName": "D"
                }
            },
            {
                "id": "6f6f8d5d-7084-48ac-b945-ee97b178c4c1",
                "name1": {
                    "id": "7c9eb64b-41b7-4451-a02e-54e280b5fc8d",
                    "firstName": "Jacob",
                    "lastName": "D"
                },
                "name2": {
                    "id": "1385e200-571d-4582-bbe8-1a534db43c11",
                    "firstName": "Stacy",
                    "lastName": "D"
                }
            },
            {
                "id": "6cc7d688-2c62-46d3-884c-f42bd56e5d7d",
                "name1": {
                    "id": "efcd5b0c-886c-410e-8a61-c8df1d3c8930",
                    "firstName": "Stacy",
                    "lastName": "D"
                },
                "name2": {
                    "id": "3ad25f92-76ab-452a-a3a6-78fcf8c2c49b",
                    "firstName": "Sam",
                    "lastName": "C"
                }
            }
        ]
    }
]