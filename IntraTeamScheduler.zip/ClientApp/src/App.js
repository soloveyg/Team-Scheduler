import React, {useState} from 'react';
import './App.css';
import Schedule from './components/Schedule';

function App() {
   

    return (
        <div className={"app"}>
            <Schedule />
        </div>
    );
}

export default App;
