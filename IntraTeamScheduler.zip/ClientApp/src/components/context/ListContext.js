import {createContext, useContext, useState} from "react";
import {useApiContext} from "./ApiContext";

const listContext = createContext({});
export const useListContext = () => useContext(listContext);

export const ListContextWrapper = ({children}) => {
    const {callToAddPeople} = useApiContext();
    //Old name list
    const [namesList, setNamesList] = useState([]);
    //Old blacklist
    const [blacklist, setBlacklist] = useState([]);


    //Regular name list
    //Adds name
    const addName = name => {
        if (!name.text || /^\s*$/.test(name.text)) {
            return;
        }
        const newNames = [name, ...namesList];
        //here I am displaying to console my names
        setNamesList(newNames);
        console.log(name, ...namesList);
    };
    //Updates the names
    const updateName = (nameId, newValue) => {
        if (!newValue.text || /^\s*$/.test(newValue.text)) {
            return;
        }

        setNamesList(prev => prev.map(item => (item.id === nameId ? newValue : item)));
    };

    //Removes the name
    const removeName = id => {
        const removedArr = [...namesList].filter(name => name.id !== id);

        setNamesList(removedArr);
    };

    const displayName = id => {
        let updatedNames = namesList.map(name => {
            if (name.id === id) {
                name.isComplete = !name.isComplete;
            }
            return name;
        });
        setNamesList(updatedNames);
    };


    //blacklist update name
    const updateBlacklistName = (nameId, newValue) => {
        if (!newValue.text || /^\s*$/.test(newValue.text)) {
            return;
        }

        setBlacklist(prev => prev.map(item => (item.id === nameId ? newValue : item)));
    };


    //remove blacklist name
    const removeBlacklistName = id => {
        const removedArr = [...blacklist].filter(name => name.id !== id);

        setBlacklist(removedArr);
    };

    //Display blacklist blacklist
    const displayNameBlackList = id => {
        let updatedNames = blacklist.map(name => {
            if (name.id === id) {
                name.isComplete = !name.isComplete;
            }
            return name;
        });
        setBlacklist(updatedNames);
    };
    const addBlacklistNames = names => {
        setBlacklist([...names,...blacklist])
    };
    const addToBlacklist = () => {
        callToAddPeople().then()
    }
    const providerApi = {
        blacklist,
        setBlacklist,
        addToBlacklist
    }
    
    return(
        <ListContextWrapper value={providerApi}>
            {children}
        </ListContextWrapper>
    )
}