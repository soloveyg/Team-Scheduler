import {createContext, useContext} from "react";

const ApiContext = createContext({});

export const useApiContext = () => useContext(ApiContext);

export const ApiContextWrapper = ({children}) => {
    const callToGetPeople = () => {
        
    }
    
    const callToAddPeople = () => {
        
    }
    const providerApi = {
        callToAddPeople,
        callToGetPeople
    }
    return(
        <ApiContext.Provider value={providerApi}>
            {children}
        </ApiContext.Provider>
    )
}