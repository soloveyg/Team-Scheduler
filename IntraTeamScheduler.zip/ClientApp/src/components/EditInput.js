import {useEffect, useRef} from "react";


//Base of the edit and delete function.
export function EditInput(props) {
    const inputRef = useRef(null);
    const handleChange = e => {
        props.setInput(e.target.value);
        
    };

    useEffect(() => {
        if(props.focus){
        inputRef.current.focus();
        }
    });
    return (
            <input
                className={"form-control shadow-none"}
                placeholder={props.edit ? 'Update your info' : props.label}
                value={props.input}
                onChange={handleChange}
                name='text'
                ref={inputRef}
                autoComplete="off"
            />
    )
}