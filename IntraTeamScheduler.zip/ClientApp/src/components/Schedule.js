import React, {useEffect, useState} from 'react';
import CreatePairsButton from "./CreatePairsButton";
import OutPutSheet from "./OutPutSheet";
import NamesEditor from "./nameslist/NamesEditor";
import BlackListPairs from "./blacklist/BlackListPairs";
import CollapsibleTeamButton from "./nameslist/CollapsibleTeamButton";
import EmployeeForm from "./nameslist/EmployeeForm";
import NamesEditorBlackList from "./blacklist/NamesEditorBlackList";
import EditModeButton from "./EditModeButton";


const URL = 'https://localhost:7211';

//Making a commit
function Schedule() {
    const [isEditMode, setIsEditMode] = useState(true);
    //Old blackList
    const [blackList, setBlackList] = useState([]);
    const [schedule, setSchedule] = useState([])
    const [loading, setLoading] = useState(false)
    //Used for Api call
    const [teamMates,setTeamMates] = useState([])
    //For the collapsable button
    const[hasCollapsed, setHasCollapsed] = useState(false)
    //For the BlackList collapsable button
    const[hasBlackListCollapsed, setBlackListIfCollapsed] = useState(false)
    
    const fetchSchedule = async () => {
        setSchedule([])
        setLoading(true);

        const requestOptions = {
            method: 'GET',
            headers: {'Content-Type': 'application/json'},
        };
        fetch(URL + '/NamePairs/SchedulePairs', requestOptions)
            .then(resp => resp.json())
            .then((data) => {
                setTimeout(() => {
                    setSchedule(data)
                    setLoading(false);
                }, 0);
            });

    }
   /* const fetchTeam = () => {
        const requestOptions = {
            method: 'GET',
            headers: {'Content-Type': 'application/json'},
        };
        fetch(URL + '/NamePairs/getTeam', requestOptions)
            .then(resp => resp.json())
            .then((data) => {
                let displayTeamMates = [...data];
                let count = 1;
                data.forEach((teammate) =>{
                    const duplicateTeamMate = displayTeamMates.filter(tm => tm.firstName === teammate.firstName
                        && tm.lastName === teammate.lastName 
                        && tm.id !== teammate.id);
                    
                    if (duplicateTeamMate.length > 0){
                        duplicateTeamMate.forEach((dupTeamMate) => {
                            const dupIndex = displayTeamMates.findIndex(dtm => dtm.id === dupTeamMate.id);
                            displayTeamMates[dupIndex] = {
                                ...dupTeamMate,
                                displayName: `${teammate.firstName} ${teammate.lastName}(${count})`
                            }
                            count++;
                            }
                        )
                    } else {
                        teammate.displayName = `${teammate.firstName} ${teammate.lastName}`;
                    }
                })
                setTeamMates(displayTeamMates);
            });
    }*/
    const fetchTeam = () => {
        const requestOptions = {
            method: 'GET',
            headers: {'Content-Type': 'application/json'},
        };
        fetch(URL + '/NamePairs/getTeam', requestOptions)
            .then(resp => resp.json())
            .then((data) => {
                setTeamMates(data)
            });
    }

    //"+" button regular list
    const addTeammate = (singleTeammate) => {

        const body = JSON.stringify(singleTeammate);
        
        const requestOptions = {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body
        };
        fetch(URL + '/NamePairs/AddTeammate', requestOptions)
            .then(() =>  fetchTeam());
    }

    //Edit button
    const editTeammate = (employee) => {

        const body = JSON.stringify(employee);

        const requestOptions = {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body
        };
        fetch(URL + '/NamePairs/EditTeammate', requestOptions)
            .then(() => {
                fetchTeam();
                getBlacklistPairs();
            });
    }

    //on BlackList "+"
    const addBlacklistPair = async (blackListPairs) => {
        
        const body = JSON.stringify(blackListPairs);

        const requestOptions = {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body
        };
        fetch(URL + '/NamePairs/AddBlacklistPair', requestOptions)
            .then(() =>  getBlacklistPairs());
    }

    //Blacklist delete works
    //delete button for BlackList
    const deleteBlacklistPair = async (id) => {

        const body = JSON.stringify(id);

        const requestOptions = {
            method: 'DELETE',
            headers: {'Content-Type': 'application/json'},
            body
        };
        fetch(URL + '/NamePairs/DeleteBlacklistPair', requestOptions)
            .then(() => getBlacklistPairs());
    }

    
    //Not implemented 
    const getEmployee =  () => {
        const requestOptions = {
            method: 'GET',
            headers: {'Content-Type': 'application/json'},
        };
        fetch(URL + '/NamePairs/GetTeammate', requestOptions)
            .then(() =>  getBlacklistPairs());
    }
    
    const getBlacklistPairs = () => {

        const requestOptions = {
            method: 'GET',
            headers: {'Content-Type': 'application/json'},
        };
        fetch(URL + '/NamePairs/GetBlacklistPairs', requestOptions)
            .then(resp => resp.json())
            .then((data) => {
                setBlackList(data)
            });
        
    }

    const deleteTeammate = (employee) => {

        const body = JSON.stringify(employee);
        
        const requestOptions = {
            method: 'DELETE',
            headers: {'Content-Type': 'application/json'},
            body
        };
        fetch(URL + '/NamePairs/DeleteTeammate', requestOptions)
            .then(() => {
                fetchTeam();
                getBlacklistPairs();
            });
    }

    useEffect(() => {
        fetchTeam()
        getBlacklistPairs();
    }, []);

    const twoColumnGridStyle = {
        width: '100%',
        display: 'grid',
        gridTemplateColumns: '50% 50%',
        justifyItems: 'center'
    }

    const nameListStyle = {
        minWidth: '550px'
    }

    const buttonStyle = {
        width: '100%',
        justifyContent: 'center',
        display: 'flex'
    }
    
    const handleCreatePairsClick = () => {

        fetchSchedule();

        setIsEditMode(false);

    }
    const maxWidthStyle = {
        paddingTop: '10px',
        paddingBottom: '10px',
        display: 'grid',
        gridTemplateColumns: '50% 50%'

    }
    
    
    return (
        <>
            <div style={buttonStyle}>
                <div style={maxWidthStyle}>
                {!isEditMode && <EditModeButton onClick={() => setIsEditMode(true)}/>}
            <CreatePairsButton onClick={handleCreatePairsClick}  loading={loading} />
                </div>
            </div>
            {isEditMode && <>
            
            <div style={twoColumnGridStyle}>
            <div style={nameListStyle}>
            <h2>Intra Meeting Scheduler:</h2>
            <CollapsibleTeamButton onClick={() => setHasCollapsed(!hasCollapsed)} label={'Team'}/>
            {hasCollapsed && <> <EmployeeForm onSubmit={addTeammate}/>
                <NamesEditor
                    employees={teamMates}
                    removeEmployee={deleteTeammate}
                    updateEmployee={editTeammate}
                />
            </>}
            </div>
            
            <div style={nameListStyle}>
            <h2>Blacklist pairs:</h2>
            <CollapsibleTeamButton onClick={() => setBlackListIfCollapsed(!hasBlackListCollapsed)}  label={'Blacklist'}/>
            {hasBlackListCollapsed && <><BlackListPairs onSubmit={addBlacklistPair} teamMates={teamMates} blackList={blackList} />
                <NamesEditorBlackList
                    blackList={blackList}
                    removeBlackListPair={deleteBlacklistPair}
                />
                </>}
            </div>
            </div>
            </>}

            {!isEditMode && <OutPutSheet pairs={schedule}/>}
           
        </>
    );
  
}

export default Schedule;