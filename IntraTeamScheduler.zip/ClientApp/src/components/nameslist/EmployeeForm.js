import React, {useState} from 'react';
import {EditInput} from "../EditInput";
import {Employee} from "../../model/Employee";


//Working Blacklist form
function EmployeeForm(props) {
    const [isOpen, setIsOpen] = useState(false)
    //the value of the state
    const [firstName, setFirstName] = useState(props.edit ? props.edit.firstName : '');
    const [lastName, setLastName] = useState(props.edit ? props.edit.lastName : '');
    const [email, setEmail] = useState(props.edit ? props.edit.lastName : '');
    function handleOnSubmit(e) {
        e.preventDefault();
        if (firstName?.length <= 0 || lastName?.length <= 0 || email.length <= 0
        || /^\s*$/.test(firstName.text) || /^\s*$/.test(lastName.text)){
            setIsOpen(true);
            return;
        }
        const employee = new Employee( firstName, lastName, email);
        props.onSubmit(employee);
        setFirstName('');
        setLastName('');
        setEmail('');
    }

    const maxWidthStyle = {

        maxWidth: '550px',
        paddingTop: '10px',
        paddingBottom: '10px'

    }
    const errorHandleStyle = {

        maxWidth: '550px',
        paddingTop: '10px',
        paddingBottom: '10px',
        paddingRight: '20px',
        paddingLeft: '20px'

    }
    const deleteStyle = {

        float: 'right'

    }
   

    return (
        <>
            <form className={'input-group'}
                  style={maxWidthStyle}>
                <EditInput
                    type={"text"}
                    setInput={setFirstName}
                    input={firstName}
                    edit={props.edit}
                    label={'Add first name'}
                />
                <EditInput
                    type={"text"}
                    setInput={setLastName}
                    input={lastName}
                    edit={props.edit}
                    label={'Add last name'}
                />
                <EditInput
                    type={"text"}
                    setInput={setEmail}
                    input={email}
                    edit={props.edit}
                    label={'Add Email!'}
                />
                <button onClick={handleOnSubmit} className={"input-group-text shadow-none"}
                //Removed "(props.edit ? 'name-input edit' : 'name-input')"
                //might break in future features but not sure.    
                >
                    {props.edit ? 'Update' : '+'}
                </button>
            </form>
            {isOpen && <div style={errorHandleStyle} className="alert alert-danger" role="alert"> Fill in all the above!
                <button style={deleteStyle} type="button" className="btn-close" onClick={() => setIsOpen(false)} aria-label="Close"></button>
            </div> }
        </>
    )


}

export default EmployeeForm;