

function CollapsibleTeamButton(props){
    
    const maxWidthStyle = {

        maxWidth: '550px',
        paddingTop: "20px",
        paddingBottom: "20px"
        
    }
    
    return (
        <div className="d-grid gap-2">
        <button onClick={props.onClick} 
                className="btn btn-primary shadow-none" 
                style={maxWidthStyle}
                type="button" 
                data-toggle="collapse" 
                data-target="#collapseExample" 
                aria-expanded="false" 
                aria-controls="collapseExample">{props.label}</button>
        </div>
    )
}

export default CollapsibleTeamButton;