import React, {useState} from 'react';
import {RiCloseCircleLine} from 'react-icons/ri';
import {TiEdit} from 'react-icons/ti';
import EmployeeForm from "./EmployeeForm";

const NamesEditor = ({employees, removeEmployee, updateEmployee}) => {
    const [edit, setEdit] = useState({
        id: null,
        firstName: '',
        lastName: '',
        email: ''
    });

    const submitUpdate = value => {
        value.id = edit.id
        updateEmployee(value);
        setEdit({
            id: null,
            firstName: '',
            lastName: '',
            email: ''
        });
    };

    const handleEditClick = (employee) => {
        setEdit(employee)
    }
    if (edit.id) {
        return <EmployeeForm edit={edit} onSubmit={submitUpdate}/>;
    }

    return( 
        employees.map((employee, index) => (
        <div
            key={index}
            className={"rounded-corners"}
        >
      <span className='icons'>
        <RiCloseCircleLine
            onClick={() => removeEmployee(employee)}
            className='delete-icon'
        />
        <TiEdit
            onClick={() => handleEditClick({id: employee.id, firstName: employee.firstName, lastName: employee.lastName, email: employee.email})}
            className='edit-icon'
        />
      </span>
            {' '}
            <span key={employee.id} >
        {employee.firstName + ' ' +employee.lastName + '   ' +employee.email}
      </span>

        </div>
           
    )));
};

export default NamesEditor;