import React from 'react'

//Map to print out data from API
function Pairs({pairs}) {

    return (
        <div className={"container text-center"} style={{marginTop: '10px', marginBottom: '20px'}}>
            <div className={"row justify-content-md-center"}>{/*pairs*/}</div>
            <div>
                {/* Iterate over the keys of myMap. The keys are week1, week2, etc.*/}
                {[...pairs].map((row, rowIndex) => (
                    <div className={"resp-table-row"} key={rowIndex + 1}>
                        {/* Render the key */}
                        <div className={"table-body-cell"}>Week {rowIndex + 1}:</div>
                        {/* Iterate over the array of Pair objects for the week. See the Pair class above.*/}
                        {[...row.meetings].map((pair, pairIndex) => (
                            <div className={"table-body-cell"} key={pairIndex + 1}>
                                {/* Render pair number. */}
                                <span>{'Pair: ' + (pairIndex + 1) + ': ('}</span>
                                {/* Render name1. */}
                                <span title={pair.name1.email  || 'email coming soon...'}>{pair.name1.firstName + ' ' + pair.name1.lastName}</span>
                                {', '}
                                {/* Render name2. */}
                                <span title={pair.name2.email || 'email coming soon...'}>{pair.name2.firstName + ' ' + pair.name2.lastName}</span>
                                {') '}
                            </div>
                        ))}
                    </div>
                ))}
            </div>
        </div>
    )
}

export default function OutPutSheet(props) {
    return (
        <div>
            <Pairs pairs={props.pairs}/>
        </div>
    )
}