import React, {Component} from 'react'
import {Button} from "reactstrap";


class CreatePairsButton extends Component {
    
    render() {
        const onClickHandler = this.props.onClick;
        const loading = this.props.loading;
        return (
            <div style={{marginTop: '10px', marginBottom: '10px', minWidth: '200px'}}>
                <Button
                    border="none"
                    height="200px"
                    radius="50%"
                    width="200px"
                    children="Create Pairs"
                    onClick={onClickHandler}
                    disabled={loading}
                >
                    {loading && (
                        <i
                            className="loading"
                            style={{marginRight: "5px"}}
                        />
                    )}
                    {loading && <span>Loading.....</span>}
                    {!loading && <span>Create Meetings</span>}
                </Button>
            </div>
        )
    };
}

export default CreatePairsButton
