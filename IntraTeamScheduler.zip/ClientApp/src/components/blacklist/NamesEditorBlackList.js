import React from 'react';
import {RiCloseCircleLine} from 'react-icons/ri';

const NamesEditorBlackList = ({blackList, removeBlackListPair}) => {
    
    return blackList.map((blackList, index) => (
        <div
            key={index}
            className={"rounded-corners"}
        >
      <span className='icons'>
        <RiCloseCircleLine
            onClick={() => removeBlackListPair(blackList.id)}
            className='delete-icon'
        />
      </span>
            {' '}
            <span key={blackList.id} >
        {blackList.name1.firstName + ' ' + blackList.name1.lastName + ' & ' + blackList.name2.firstName + ' ' + blackList.name2.lastName}
      </span>
        </div>
    ));
};

export default NamesEditorBlackList;