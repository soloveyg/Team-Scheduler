
import React, {useState} from 'react'
import Select from 'react-select'

function BlacklistPairs({onSubmit, teamMates, blackList}) {

    
    const [errormssg, setErrormssg] = useState('')
    const [isOpen, setIsOpen] = useState(false)
    
    const [name1, setName1] = useState();
    const [name2, setName2] = useState();

    const options = teamMates.map((person, index) => { return { label: person.firstName + ' ' + person.lastName , value: person, key: index } })
    
    
    //id?.length
    function handleOnSubmit(e) {
        e.preventDefault();
        

            if (!name1 || name1.firstName <= 0
                ||!name2 || name2.firstName <= 0) {
                setIsOpen(true);
                setErrormssg('Names cannot be empty!');
                return;
            }
            if (name1.id === name2.id) {
                setIsOpen(true);
                setErrormssg('Names cannot be the same!');
                return;
            }
            if (blackList?.some(e => e.name1.id === name1.id) && blackList?.some(e => e.name2.id === name2.id)
                || blackList?.some(e => e.name1.id === name2.id) && blackList?.some(e => e.name2.id === name1.id)) {
                setIsOpen(true);
                setErrormssg('Pair already exists in blacklist!');
                return;
        }
        const data = {
            id : '3ba85f64-5717-4562-b3fc-2c963f66afa6',
            name1 : name1,
            name2: name2
        }
        onSubmit(data);
    }

    const maxWidthStyle = {
        width: '100%',
        paddingTop: '10px',
        paddingBottom: '10px',
        display: 'grid',
        gridTemplateColumns: '1fr 1fr 40px'

    }
    const errorHandleStyle = {

        maxWidth: '550px',
        paddingTop: '10px',
        paddingBottom: '10px',
        paddingRight: '20px',
        paddingLeft: '20px'

    }
    const deleteStyle = {
        float: 'right'
    }

    return (
        <>
            <form className='blacklist-pairs'>
                <div className="input-group">
                    <div style={maxWidthStyle}>
                    <span>
                    <Select name="blacklist1"
                            id="inputGroupSelect04"
                            className="shadow-none" 
                            aria-label="Example select with button addon"
                            defaultValue={name1}
                            onChange={(event)=>setName1(event.value)}
                            options={options}
                            placeholder={"Select a name"}
                    >
                    </Select>
                        </span>
                    
                    
                <span>
                    <Select name="blacklist2"
                            id="inputGroupSelect05"
                            className="shadow-none"
                            aria-label="Example select with button addon"
                            defaultValue={name2}
                            onChange={(event)=>setName2(event.value)}
                            options={options}
                            placeholder={"Select a name"}
                    >
                    </Select>
                </span>
                    <button onClick={handleOnSubmit} className="btn btn-outline-secondary shadow-none" type="button">
                        {'+'}
                    </button>
                    </div>
                </div>
            </form>
            {isOpen && <div style={errorHandleStyle} className="alert alert-danger" role="alert"> {errormssg}
                <button style={deleteStyle} type="button" className="btn-close" onClick={() => setIsOpen(false)} aria-label="Close"></button>
            </div> }
        </>
    )


}

export default BlacklistPairs;